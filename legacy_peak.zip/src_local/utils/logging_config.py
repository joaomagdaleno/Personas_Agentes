import logging
import sys

def configure_logging(level=logging.INFO):
    """
    🛰️ Configura o sistema de logging PhD resiliente.
    Garante suporte a UTF-8 (emojis), formatação determinística e isolamento de fluxos
    mesmo em ambientes hostis como o terminal do Windows.
    """
    # Cores simples para evitar erros de format string
    class SimpleFormatter(logging.Formatter):
        def format(self, record):
            """🧬 Formatação manual PhD para estabilidade absoluta."""
            level_name = record.levelname
            msg = record.getMessage()
            time_str = self.formatTime(record, self.datefmt)
            return f"{time_str} - {record.name} - {level_name} - {msg}"

    try:
        # Força UTF-8 no StreamHandler para suportar emojis no Windows
        import io
        if hasattr(sys.stdout, 'reconfigure'):
            sys.stdout.reconfigure(encoding='utf-8')
        
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(SimpleFormatter())
        root = logging.getLogger()
        root.setLevel(level)
        for h in root.handlers[:]: root.removeHandler(h)
        root.addHandler(handler)
    except Exception as e:
        # Veto de Silenciamento: Reporta falha no fluxo de erro padrão
        sys.stderr.write(f"🚨 [Logging] Falha fatal na instrumentação: {e}\n")

def setup_logging(level=logging.INFO): configure_logging(level)

def log_performance(logger, start_time, message, level=logging.DEBUG):
    """🛰️ Utilitário soberano para telemetria de performance padronizada."""
    import time
    duration = time.time() - start_time
    logger.log(level, f"{message} in {duration:.4f}s.")

if not logging.getLogger().handlers: configure_logging()

