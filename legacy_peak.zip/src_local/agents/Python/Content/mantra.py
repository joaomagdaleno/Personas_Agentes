from src_local.agents.base import BaseActivePersona
import logging
import time

logger = logging.getLogger(__name__)

class MantraPersona(BaseActivePersona):
    """Core: PhD in Quality 🧘"""
    
    def __init__(self, project_root):
        super().__init__(project_root)
        self.name, self.emoji, self.role, self.stack = "Mantra", "🧘", "PhD Quality Architect", "Python"

    def perform_audit(self) -> list:
        start_time = time.time()
        logger.info(f"[{self.name}] Analisando Pureza do Código...")
        
        audit_rules = [
            {'regex': r"except" + r":\s+pass", 'issue': 'Anti-padrão: Bare except.', 'severity': 'critical'},
            {'regex': r"\bglobal\s+\w+", 'issue': 'Violação: Uso de estado global detectado.', 'severity': 'high'}
        ]
        
        results = self.find_patterns(('.py',), audit_rules)
        self._log_performance(start_time, len(results))
        return results

    def _reason_about_objective(self, objective, file, content):
        # O Mantra agora delega a auditoria de pureza para o AuditEngine via perform_audit
        return None

    def get_system_prompt(self):
        return f"Você é o Dr. {self.name}, guardião da qualidade."
